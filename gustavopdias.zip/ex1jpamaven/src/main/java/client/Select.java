package client;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import objects.Produto;

public class Select {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
				
		em.getTransaction().begin();
		
		em.find(Produto.class, 1);
		
		System.out.println(em.find(Produto.class, 1));
		
		em.close();
		emf.close();
	}

}



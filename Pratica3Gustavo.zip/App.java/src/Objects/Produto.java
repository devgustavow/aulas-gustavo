package Objects;

public class Produto {
	private int cod;
	private String nome;
	private int categoria;

	
	public Produto(int cod, String nome, int categoria ) {
		this.cod = cod;
		this.categoria = categoria;
		this.nome = nome;
	}
	public int getCod() {
		return cod;
	}
	
	public void setCod(int cod) {
		this.cod = cod;
	}
	
	public String getNome() {
		return nome;
		
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Produto() {
		
	}
}

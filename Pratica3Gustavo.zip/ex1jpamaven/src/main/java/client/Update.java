package client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import objects.Produto;

public class Update {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();

		String novoNome = "Produto Novo";
		Integer novaCategoria = 10;

		em.getTransaction().begin();

		
		Produto novo = em.find(Produto.class, 3);

		novo.setNome(novoNome);
		novo.setCategoria(novaCategoria);

		
		em.getTransaction().commit();

		System.out.println("Produto atualizado com sucesso: " + novo);

		
		em.close();
		emf.close();

	}

}